# Pruebas de Redis en Python

Prueba funcional de el uso de la base de datos Redis en un entorno de python, simplemente dos archivos con los scripts tanto para enviar un mensaje como para visualizar los mensajes hechos por el primer script.
1. Publisher publica las publicaciones como un mensaje
2. Suscriber Visualiza todos los mensajes que se suban
